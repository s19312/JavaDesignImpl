package edu.pl.mas.s19312.mp2.withAttribute;

public enum Equipment {
    CLASSIC,
    COMFORT,
    SPORT
}
