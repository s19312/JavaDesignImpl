package edu.pl.mas.s19312.mp2.withAttribute;

import java.time.LocalDateTime;

public class Details {
    private double carPrice;
    private LocalDateTime purchaseDate;
    private String insuranceNumber;
    private String plateNumber;

    private Car car;
    private Owner owner;

    public Details(double carPrice, LocalDateTime purchaseDate, String insuranceNumber, String plateNumber, Car car, Owner owner) {
        setCarPrice(carPrice);
        setPurchaseDate(purchaseDate);
        setInsuranceNumber(insuranceNumber);
        setPlateNumber(plateNumber);
        setCar(car);
        setOwner(owner);
    }

    public double getCarPrice() {
        return carPrice;
    }

    public void setCarPrice(double carPrice) {
        this.carPrice = carPrice;
    }

    public LocalDateTime getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDateTime purchaseDate) {
        if(purchaseDate == null){
            throw new RuntimeException("Purchase Date cannot not be null!");
        }
        this.purchaseDate = purchaseDate;
    }

    public String getInsuranceNumber() {
        return insuranceNumber;
    }

    public void setInsuranceNumber(String insuranceNumber) {
        if(insuranceNumber == null || insuranceNumber.trim().equals("")){
            throw new RuntimeException("Insurance Number cannot be null or empty!");
        }
        this.insuranceNumber = insuranceNumber;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        if(plateNumber == null || plateNumber.trim().equals("")){
            throw new RuntimeException("Plate Number cannot be null or empty!");
        }
        this.plateNumber = plateNumber;
    }

    public Car getCar() {
        return car;
    }

    private void setCar(Car car) {
        if(car == null){
            throw new RuntimeException("Car cannot be null");
        }
        this.car = car;
        car.setDetails(this);
    }

    public Owner getOwner() {
        return owner;
    }

    private void setOwner(Owner owner) {
        if(owner == null){
            throw new RuntimeException("Owner cannot be null");
        }
        this.owner = owner;
        owner.addDetails(this);
    }

    public void remove(){
        if (this.car != null) {
            car.removeDetails(this);
            this.car = null;
        }
        if (this.owner != null) {
            owner.removeDetails(this);
            this.owner = null;
        }
    }
}
