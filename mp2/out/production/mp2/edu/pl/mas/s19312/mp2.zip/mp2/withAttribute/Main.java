package edu.pl.mas.s19312.mp2.withAttribute;

import java.time.LocalDateTime;

public class Main {

    public static void main(String[] args) {
        Car c1 = new Car(1,"toyota", Equipment.CLASSIC);
        //Car brand cannot be null or empty! error
//        Car c2 = new Car(2,"", Equipment.CLASSIC);
        Car c3 = new Car(3,"BMW", Equipment.SPORT);
        Car c4 = new Car(3,"BMW", Equipment.SPORT);

        Owner o1 = new Owner(1,"Jacek", "Smith", LocalDateTime.now(),"FF33432");
        Owner o2 = new Owner(2,"Johm", "Kowalski", LocalDateTime.now(),"FF35732");

        //firstName and lastname cannot be null or empty! error
//        Owner o3 = new Owner(3,"", null, LocalDateTime.now(),"FF12432");

        Owner o4 = new Owner(3,"Jacub", "Nowak", LocalDateTime.now(),"FF66432");

        Details d1 = new Details(1000,LocalDateTime.now(),"ss44w2355","AA54435TG",c1,o1);
        d1.remove();

        Details d2 = new Details(1500,LocalDateTime.now(),"4564s9845","AO12356BG",c3,o1);
        o1.removeDetails(d2);
        //resign c1 to another Owner
        Details d3 = new Details(2250,LocalDateTime.now(),"r88432498","AI55665BG",c1,o2);

        //This Details assign to another car! error
//        c1.setDetails(d2);

        c1.removeDetails(d3);


    }
}
