package edu.pl.mas.s19312.mp2.withAttribute;

public class Car {
    private long id;
    private String brand;
    private Equipment carEquipment;

    private Details details;

    public Car(long id, String brand, Equipment carEquipment) {
        setId(id);
        setBrand(brand);
        setCarEquipment(carEquipment);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        if(id < 0){
            throw new RuntimeException("Car Id cannot be negative!");
        }
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        if(brand == null || brand.trim().equals("")){
            throw new RuntimeException("Car brand cannot be null or empty!");
        }
        this.brand = brand;
    }

    public Equipment getCarEquipment() {
        return carEquipment;
    }

    public void setCarEquipment(Equipment carEquipment) {
        if(carEquipment == null){
            throw new RuntimeException("Car Equipment cannot be null");
        }
        this.carEquipment = carEquipment;
    }

    public Details getDetails() {
        return details;
    }

    public void setDetails(Details details) {
        if(details == null){
            throw new RuntimeException("Details cannot be null");
        }
        if(this != details.getCar()){
            throw new RuntimeException("This Details assign to another car!");
        }
        if(this.details != details && details.getCar() == this && this.details != null){
            this.details.remove();
        }
        this.details = details;
    }

    public void removeDetails(Details details){
        if(this.details == null){
            return;
        }
        this.details = null;
        details.remove();

    }
}
