package edu.pl.mas.s19312.mp2.composition;

public class Main {

    public static void main(String[] args) {
        Album a1 = new Album("something");
        Album a2 = new Album("something2");
        Song s1 = new Song("Best Life1", a1);
        Song s2 = new Song("Best Life2", a1);

        System.out.println(a1.getSongs().size());

        a1.removeSongs(s2);
        System.out.println(a1.getSongs().size());

        s1.removeAlbum(a1);
        System.out.println(a1.getSongs().size());
        System.out.println(s1.getAlbum());

        a1.addSongs(s1);
        //Song sign to another Album
//        a2.addSongs(s1);
        System.out.println(a1.getSongs().size());
        //trying to add the same song twice
        a1.addSongs(s1);
        System.out.println(a1.getSongs().size());

        s1.removeAlbum(a1);
        System.out.println(a1.getSongs().size());

    }
}
