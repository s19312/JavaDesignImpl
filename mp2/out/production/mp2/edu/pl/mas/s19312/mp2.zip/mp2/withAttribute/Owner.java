package edu.pl.mas.s19312.mp2.withAttribute;

import edu.pl.mas.s19312.mp2.basic.Group;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Owner {
    private int idOwner;
    private String firstName;
    private String lastName;
    private LocalDateTime dateOfBirth;
    private String pesel;

    private List<Details> details = new ArrayList<>();

    public Owner(int idOwner, String firstName, String lastName, LocalDateTime dateOfBirth, String pesel) {
        setIdOwner(idOwner);
        setFirstName(firstName);
        setLastName(lastName);
        setDateOfBirth(dateOfBirth);
        setPesel(pesel);
    }

    public int getIdOwner() {
        return idOwner;
    }

    public void setIdOwner(int idOwner) {
        this.idOwner = idOwner;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        if(firstName == null || firstName.trim().equals("")){
            throw new RuntimeException("firstName cannot be null or empty");
        }
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        if(lastName == null || lastName.trim().equals("")){
            throw new RuntimeException("lastName cannot be null or empty");
        }
        this.lastName = lastName;
    }

    public LocalDateTime getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDateTime dateOfBirth) {
        if(dateOfBirth == null){
            throw new RuntimeException("lastName cannot be null or empty");
        }
        this.dateOfBirth = dateOfBirth;
    }

    public String getPesel() {
        return pesel;
    }

    public void setPesel(String pesel) {
        if(pesel == null || pesel.trim().equals("")){
            throw new RuntimeException("pesel cannot be null or empty");
        }
        this.pesel = pesel;
    }

    public List<Details> getDetails() {
        return Collections.unmodifiableList(details);
    }

    public void addDetails(Details details) {
        if(details == null){
            throw new RuntimeException("Details cannot be null");
        }
        if(details.getOwner() != this && details.getOwner() != null){
            throw new RuntimeException("This Details assign to another Owner");
        }
        if(this.details.contains(details)){
            return;
        }
        this.details.add(details);
    }

    public void removeDetails(Details details) {
        if(details == null){
            throw new RuntimeException("Details cannot be null");
        }
        if(!this.details.contains(details)){
            return;
        }
        this.details.remove(details);
        details.remove();
    }
}
