package edu.pl.mas.s19312.mp2.qualified;

public enum MusicType {
    ROCK,
    POP,
    RAP
}
