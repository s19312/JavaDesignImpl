package edu.pl.mas.s19312.mp2.basic;

import java.time.LocalDateTime;

public class Main {

    public static void main(String[] args) {
        Student s1 = new Student(1, "John", "Smith", LocalDateTime.now());
        Student s2 = new Student(2, "Jan", "Kowak", LocalDateTime.now());
        Student s3 = new Student(3, "Max", "Kowalski", LocalDateTime.now());
//        Student s4 = new Student(4, "", null, LocalDateTime.now());//firstname and lastname error

        Group g1 = new Group("15a",s1);
        g1.addStudent(s2);
        g1.addStudent(s3);
        g1.removeStudent(s2);
        g1.removeStudent(s3);

//        Group g2 = new Group("",s1);//id group cannot be null Exception
        Group g3 = new Group("16a",s1);//cannot remove last Student "s1" from first group to assign it to another group
        System.out.println(g1.getStudents().size());
        System.out.println(g3.getStudents().size());
    }
}
